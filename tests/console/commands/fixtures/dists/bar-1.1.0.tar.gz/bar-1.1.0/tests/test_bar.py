#!/usr/bin/env python

"""Tests for `bar` package."""


import unittest

from bar import bar


class TestBar(unittest.TestCase):
    """Tests for `bar` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
