========
Bar Test
========


.. image:: https://img.shields.io/pypi/v/bar.svg
        :target: https://pypi.python.org/pypi/bar

.. image:: https://img.shields.io/travis/yoyodyne/bar.svg
        :target: https://travis-ci.com/yoyodyne/bar

.. image:: https://readthedocs.org/projects/bar/badge/?version=latest
        :target: https://bar.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Bar


* Free software: MIT license
* Documentation: https://bar.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
