=====
Usage
=====

To use Bar Test in a project::

    import bar
