=======
History
=======

1.1.0 (2020-07-12)
------------------

* First release on PyPI.
