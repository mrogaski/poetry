"""Top-level package for Foo Test."""

__author__ = """John Whorfin"""
__email__ = 'joh.whorfin@yoyodyne.com'
__version__ = '1.0.0'
