"""Top-level package for Bar Test."""

__author__ = """John Whorfin"""
__email__ = 'john.whorfin@yoyodyne.com'
__version__ = '1.1.0'
