=====
Usage
=====

To use Foo Test in a project::

    import foo
