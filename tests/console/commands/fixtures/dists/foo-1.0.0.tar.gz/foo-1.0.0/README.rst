========
Foo Test
========


.. image:: https://img.shields.io/pypi/v/foo.svg
        :target: https://pypi.python.org/pypi/foo

.. image:: https://img.shields.io/travis/yoyodyne/foo.svg
        :target: https://travis-ci.com/yoyodyne/foo

.. image:: https://readthedocs.org/projects/foo/badge/?version=latest
        :target: https://foo.readthedocs.io/en/latest/?badge=latest
        :alt: Documentation Status




Foo


* Free software: MIT license
* Documentation: https://foo.readthedocs.io.


Features
--------

* TODO

Credits
-------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage
