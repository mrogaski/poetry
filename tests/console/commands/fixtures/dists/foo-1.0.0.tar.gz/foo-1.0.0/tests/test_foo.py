#!/usr/bin/env python

"""Tests for `foo` package."""


import unittest

from foo import foo


class TestFoo(unittest.TestCase):
    """Tests for `foo` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""
